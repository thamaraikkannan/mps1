package com.cg.mps.service;


import java.util.List;


import com.cg.mps.bean.MobilesBean;
import com.cg.mps.bean.PurchaseDetailsBean;
import com.cg.mps.dao.IMobilePurchaseDao;
import com.cg.mps.dao.MobilePurchaseDaoImpl;
import com.cg.mps.exception.MobileException;

public class MobilePurchaseServiceImpl implements IMobilePurchaseService{

	private IMobilePurchaseDao mobilepurchaseDao = new MobilePurchaseDaoImpl(); 
	@Override
	public int addCustomer(PurchaseDetailsBean Pbean) throws MobileException {
		int id = 0;
		id = mobilepurchaseDao.addCustomer(Pbean);
		return id;
	}

	

	@Override
	public MobilesBean deleteMobiles(int MobileId) throws MobileException {
		
		MobilesBean Mbean = null;
		Mbean = mobilepurchaseDao.deleteMobiles(MobileId);
		return Mbean;
	}

	/*@Override
	public int priceRangeMobiles(MobilesBean Mbean) throws MobileException {
		int id = 0;
		id = mobilepurchaseDao.priceRangeMobiles(Mbean);
		return id;
	}*/



	@Override
	public List<MobilesBean> viewAllMobiles() throws MobileException {
		List<MobilesBean> list = mobilepurchaseDao.viewAllMobiles();
		return list;
	}



	@Override
	public List<MobilesBean> priceRangeMobiles(MobilesBean Mbean)
			throws MobileException {
		List<MobilesBean> list = mobilepurchaseDao.priceRangeMobiles(Mbean);
		return list;
	}

}
