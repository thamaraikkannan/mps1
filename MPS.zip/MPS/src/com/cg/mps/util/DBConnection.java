package com.cg.mps.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import com.cg.mps.exception.MobileException;

public class DBConnection {
	public static Connection getConnection() throws MobileException{
		Connection con = null;
		try{
			FileReader fr = new FileReader("resources/jdbc.properties");
			Properties prop = new Properties();
			prop.load(fr);
		String url =prop.getProperty("dburl");
		String user=prop.getProperty("dbuser");
		String pass=prop.getProperty("dbpass");
		con = DriverManager.getConnection(url,user,pass);
		}
		catch(FileNotFoundException e)
		{
			con = null;
			throw new MobileException("jdbc.properties File not Found");
		}
		catch(IOException e)
		{
			con = null;
			throw new MobileException("Unable to Read jdbc.properties File");
		}
		catch(SQLException e)
		{
			con = null;
			throw new MobileException("Database Connection error"+e.getMessage());
		}
		return con;
	}

}
